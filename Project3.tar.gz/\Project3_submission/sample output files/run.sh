#!/bin/bash
gnome-terminal -e "bash -c \"./gateway ../SampleConfigurationFiles/PrimaryGatewayConfig.txt GatewayOutput1.log; exec bash\""
sleep 4
gnome-terminal -e "bash -c \"./database ../SampleConfigurationFiles/PrimaryBackendConfig.txt PersistentStorage1.txt; exec bash\""
sleep 4
gnome-terminal -e "bash -c \"./sgateway ../SampleConfigurationFiles/SecondaryGatewayConfig.txt GatewayOutput2.log; exec bash\""
sleep 4
gnome-terminal -e "bash -c \"./database ../SampleConfigurationFiles/SecondaryBackendConfig.txt PersistentStorage2.txt; exec bash\""
sleep 4
gnome-terminal -e "bash -c \"./door ../SampleConfigurationFiles/DoorConfig.txt ../SampleConfigurationFiles/DoorInput.txt DoorOutput.log; exec bash\""
sleep 4
gnome-terminal -e "bash -c \"./motion ../SampleConfigurationFiles/MotionConfig.txt ../SampleConfigurationFiles/MotionInput.txt MotionOutput.log; exec bash\""
sleep 4
gnome-terminal -e "bash -c \"./keychain ../SampleConfigurationFiles/KeychainConfig.txt ../SampleConfigurationFiles/KeychainInput.txt KeychainOutput.log; exec bash\""
sleep 4
gnome-terminal -e "bash -c \"./securitysystem ../SampleConfigurationFiles/SecurityDeviceConfig.txt SecurityDeviceOutput.log; exec bash\""


