#!/bin/bash
gnome-terminal -e "bash -c \"./output/gateway ConfigFiles/PrimaryGatewayConfig.txt PrimaryGatewayOutput.log; exec bash\""
sleep 4
gnome-terminal -e "bash -c \"./output/database ConfigFiles/PrimaryBackendConfig.txt PrimaryBackendOutput.log; exec bash\""
sleep 4
gnome-terminal -e "bash -c \"./output/sgateway ConfigFiles/SecondaryGatewayConfig.txt SecondaryGatewayOutput.log; exec bash\""
sleep 4
gnome-terminal -e "bash -c \"./output/database ConfigFiles/SecondaryBackendConfig.txt SecondaryBackendOutput.log; exec bash\""
sleep 4
gnome-terminal -e "bash -c \"./output/door ConfigFiles/DoorConfig.txt InputFiles/DoorInput.txt DoorOutput.log; exec bash\""
sleep 4
gnome-terminal -e "bash -c \"./output/motion ConfigFiles/MotionConfig.txt InputFiles/MotionInput.txt MotionOutput.log; exec bash\""
sleep 4
gnome-terminal -e "bash -c \"./output/keychain ConfigFiles/KeychainConfig.txt InputFiles/KeychainInput.txt KeychainOutput.log; exec bash\""
sleep 4
gnome-terminal -e "bash -c \"./output/securitysystem ConfigFiles/SecurityDeviceConfig.txt SecurityDeviceOutput.log; exec bash\""


