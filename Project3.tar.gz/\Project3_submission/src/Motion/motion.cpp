#include <cstring>
#include <unistd.h>
#include <stdio.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <stdlib.h>
#include <string>
#include <time.h>
#include <pthread.h>
#include <ctime>

using namespace std;

struct DeviceDetail
{
	string ItemType;
	string IpAddress;
	string PortNumber;
	string CurrentState;
};

bool startFlag = false;

char *ch,*ch1;
int Interval=5;
string vectorclock;
stringstream Stream;
void outputfile(string);
void *Time(void *);
void *Receive(void*);
void vectorrecv(int);
void *recvGateway(void *);
void vectorsend();
void changeGateway(string msg);
DeviceDetail devicedetail;

int SocketDescriptor;
int MyListenDescriptor;

int main(int argc, char *argv[])
{
	vectorclock="(0,0,0)";
	ch=argv[3];
	ch1=argv[2];
	string ConfigurationDetail;				// To hold data from the configuration file passed on to the Client program as command line argument
	struct sockaddr_in ServerAddress, DoorAddress;
	SocketDescriptor = socket(AF_INET, SOCK_STREAM,0);

	pthread_t TaskThread,t1,t2;

	ofstream displayfile;
	displayfile.open(ch,ios::out|ios::trunc);
	displayfile.close();

	ifstream configfile (argv[1]);				//open the above mentioned Device Configuration File and read the file
	if(configfile.is_open())
	{
		for(int Index=0;Index<2;Index++)
		{
			getline(configfile,ConfigurationDetail);

			if(Index==0)				//if its in first line of the file
			{
				int delimiter=ConfigurationDetail.find(",");
				string ServerIPAddress;
				int ServerPortNumber;
				ServerIPAddress=ConfigurationDetail.substr(0,delimiter);
				string temp=ConfigurationDetail.substr(delimiter+1,ConfigurationDetail.size()-(delimiter+1));
				ServerPortNumber=atoi(temp.c_str());

				memset(&ServerAddress,0,sizeof(ServerAddress));
				ServerAddress.sin_family=AF_INET;
				ServerAddress.sin_port=htons(ServerPortNumber);
				ServerAddress.sin_addr.s_addr=inet_addr(ServerIPAddress.c_str());

				connect(SocketDescriptor,(struct sockaddr*)&ServerAddress,sizeof(ServerAddress));
			}
			else
			{
				int delimiter=ConfigurationDetail.find(",");
				devicedetail.ItemType=ConfigurationDetail.substr(0,delimiter);
				int delimiter2=ConfigurationDetail.find(",",delimiter+1,1);
				devicedetail.IpAddress=ConfigurationDetail.substr(delimiter+1,delimiter2-(delimiter+1));
				devicedetail.PortNumber=ConfigurationDetail.substr(delimiter2+1,ConfigurationDetail.size()-(delimiter2+1));

				string RegisterMessage="Type:Register;Action:"+devicedetail.ItemType+":"+devicedetail.IpAddress+":"+devicedetail.PortNumber;
				char s[1000];
				bzero(s,1001);
				strcpy(s,RegisterMessage.c_str());
				write(SocketDescriptor,s,strlen(s));
				outputfile(RegisterMessage);
				pthread_create(&TaskThread, NULL, Time, (void*) &SocketDescriptor);
				MyListenDescriptor= socket(AF_INET, SOCK_STREAM,0);
				pthread_create(&t2, NULL, recvGateway, (void*) &SocketDescriptor);

				sleep(5);





				pthread_create(&t1,NULL,Receive,(void*)&MyListenDescriptor);

			}
		}

		configfile.close();
	}
	pthread_join(t1,NULL);
	pthread_join(TaskThread,NULL);
	pthread_join(t2,NULL);


}

void changeGateway(string msg){
	int delimiter=msg.find(":")+1;
	int delimiter2=msg.find(":",delimiter,1);

	string ServerIPAddress=msg.substr(delimiter,delimiter2-delimiter);
	string Temp2=msg.substr(delimiter2+1,msg.size()-(delimiter2-1));
	int ServerPortNumber=atoi(Temp2.c_str());

	struct sockaddr_in ServerAddress;
	memset(&ServerAddress,0,sizeof(ServerAddress));
	ServerAddress.sin_family=AF_INET;
	ServerAddress.sin_port=htons(ServerPortNumber);
	ServerAddress.sin_addr.s_addr=inet_addr(ServerIPAddress.c_str());
	SocketDescriptor = socket(AF_INET, SOCK_STREAM,0);
	connect(SocketDescriptor,(struct sockaddr*)&ServerAddress,sizeof(ServerAddress));

	string RegisterMessage="Type:Register;Action:"+devicedetail.ItemType+":"+devicedetail.IpAddress+":"+devicedetail.PortNumber;
	char s[1000];
	bzero(s,1001);
	strcpy(s,RegisterMessage.c_str());
	write(SocketDescriptor,s,strlen(s));
	outputfile(RegisterMessage);
}

void *recvGateway(void * mydesc)
{
	int k = 0;
	while(k<2){
		struct sockaddr_in DoorAddress;

		char gateway_message[1000];
		bzero (gateway_message,1001);
		int n=recv(SocketDescriptor, gateway_message,100,0);
		cout << "Message Received: "<< gateway_message << endl;
		string msg(gateway_message);
		if (msg.substr(0, msg.find(":")).compare("NEWSERVER")==0){
			changeGateway(msg);
		} else if (msg.compare("START")==0){
			startFlag = true;
			cout <<"motion eligible to start" << endl;
		}else{
			string doorconfig(gateway_message);
			int dem1=doorconfig.find(";");
			string doorip=doorconfig.substr(0,dem1);
			string doorport=doorconfig.substr(dem1+1,strlen(doorconfig.c_str())-dem1-1);
			int doorportno=atoi(doorport.c_str());


			memset(&DoorAddress,0,sizeof(DoorAddress));
			DoorAddress.sin_family=AF_INET;
			DoorAddress.sin_port=htons(doorportno);
			DoorAddress.sin_addr.s_addr=inet_addr(doorip.c_str());
			connect(MyListenDescriptor,(struct sockaddr*)&DoorAddress,sizeof(DoorAddress));
			bzero(gateway_message,1001);
		}
		k++;
	}
}

void *Time (void * socketDescriptor)
{
	while(!startFlag){
		sleep(1);
	}
	int serverSocketDescriptor = * (int *)socketDescriptor;
	int i,a=0,d1,d2;
	/*	cout<<"enter 1 to start the motion sensor"<<endl;
	cin>>i;
	cout<<"reading motion sensor state file"<<endl;*/
	while(1)
	{
		ifstream timefile(ch1);
		if (timefile.is_open())
		{

			while(!timefile.eof())
			{
				string state;
				getline(timefile,state);
				d1=state.find(",");
				d2=state.find(",",d1+1,1);
				int d3=state.find("e",d2,1);
				string tempst=state.substr(0,d1);
				int StartTime=atoi(tempst.c_str());
				string tempend=state.substr(d1+1,d2-(d1+1));
				int EndTime=atoi(tempend.c_str());
				int difference=EndTime-StartTime;
				if(Interval!=0)
				{

					difference=difference-a;
					a=difference-Interval;
					while(a>=Interval)
					{
						if(a>=Interval)
						{
							sleep(Interval);
							a=a-Interval;
						}

						time_t now=time(0);
						Stream<<now;
						string temp=Stream.str();
						Stream.str("");

						vectorsend();
						char j[100];
						bzero(j,101);
						strcpy(j,vectorclock.c_str());

						string ValueMessage="Type:MotionState;Action:"+state.substr(d2+1,(d3-(d2)))+";Timestamp:"+temp+";vector:"+vectorclock;
						char u[100];
						bzero(u,101);
						strcpy(u,ValueMessage.c_str());
						int q = send(serverSocketDescriptor, u, strlen(ValueMessage.c_str()),0);
						if (q <= 0 ){
							cout << "Data Lost: " << ValueMessage << endl;
							outputfile("Data Lost: "+ValueMessage);
						}
						send(MyListenDescriptor,j, strlen(vectorclock.c_str()),0);
						outputfile(ValueMessage);
					}
				}

			}

		}
		timefile.close();

	}

}

void *Receive (void * conndes)
{
	int client_sock=*(int*)conndes;
	while(1)
	{
		char client_message[1000];
		bzero (client_message,1001);
		int n=recv(MyListenDescriptor, client_message,100,0);
		if(n<0)
		{
			cout<<"received error"<<endl;

		}
		if(n==0)
		{
			close(client_sock);
			break;
		}
		string doorvector(client_message);
		int delimiter1=doorvector.find("Type:")+5;
		int delimiter2=doorvector.find(";Action:")+8;
		int dem3=doorvector.find(";",delimiter2,1);
		int dem4=doorvector.find("(",dem3,1)+1;
		int dem5=doorvector.find(",",dem4,1)+1;
		int dem6=doorvector.find(",",dem5,1)+1;
		string temp1=doorvector.substr(dem4,dem5-dem4-1);
		string temp2=doorvector.substr(dem5,dem6-dem5-1);
		string temp3=doorvector.substr(dem6,strlen(doorvector.c_str())-dem6-1);
		int a1=atoi(temp1.c_str());
		int a2=atoi(temp2.c_str());
		int a3=atoi(temp3.c_str());

		vectorrecv(a1);
	}

}

void vectorsend()
{

	int dem1=vectorclock.find("(")+1;
	int dem2=vectorclock.find(",")+1;
	int dem3=vectorclock.find(",",dem2,1)+1;
	string temp1=vectorclock.substr(dem1,dem2-dem1-1);
	string temp2=vectorclock.substr(dem2,dem3-dem2-1);
	string temp3=vectorclock.substr(dem3,strlen(vectorclock.c_str())-dem3-1);
	int b1=atoi(temp1.c_str());
	int b2=atoi(temp2.c_str());
	int b3=atoi(temp3.c_str());
	b2+=1;
	Stream << b2;
	temp2= Stream.str();
	Stream.str("");
	vectorclock="("+temp1+","+temp2+","+temp3+")";
	cout<<vectorclock<<endl;

}

void vectorrecv(int a)
{
	int dem1=vectorclock.find("(")+1;
	int dem2=vectorclock.find(",")+1;
	int dem3=vectorclock.find(",",dem2,1)+1;
	string temp1=vectorclock.substr(dem1,dem2-dem1-1);
	string temp2=vectorclock.substr(dem2,dem3-dem2-1);
	string temp3=vectorclock.substr(dem3,strlen(vectorclock.c_str())-dem3-1);
	int b1=atoi(temp1.c_str());
	int b2=atoi(temp2.c_str());
	int b3=atoi(temp3.c_str());
	b2+=1;
	Stream << b2;
	temp2= Stream.str();
	Stream.str("");
	b1=a;
	Stream << b1;
	temp1=Stream.str();
	Stream.str("");
	vectorclock="("+temp1+","+temp2+","+temp3+")";

}

void outputfile(string msg)
{
	ofstream outputFile;
	outputFile.open(ch,ios::app);
	outputFile<<msg<<" logged by motion sensor"<<endl;
	outputFile.close();
}
