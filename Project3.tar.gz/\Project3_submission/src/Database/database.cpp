#include <cstring>
#include <unistd.h>
#include <stdio.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <stdlib.h>
#include <string>
#include <time.h>
#include <pthread.h>
#include <ctime>

using namespace std;

struct DeviceDetail
{
	string ItemType;
	string IpAddress;
	string PortNumber;
	string CurrentState;
};

char *ch;

DeviceDetail devicedetail;

int SocketDescriptor;

int main(int argc, char *argv[])
{
	ch=argv[2];
	string ConfigurationDetail;				// To hold data from the configuration file passed on to the Client program as command line argument
	struct sockaddr_in ServerAddress, MyAddress;
	SocketDescriptor = socket(AF_INET, SOCK_STREAM,0);
	int MyListenDescriptor;
	pthread_t TaskThread;

	ifstream configfile (argv[1]);				//open the above mentioned Device Configuration File and read the file
		if(configfile.is_open())
		{
			for(int Index=0;Index<2;Index++)
			{
				getline(configfile,ConfigurationDetail);

				if(Index==0)				//if its in first line of the file
				{
					int delimiter=ConfigurationDetail.find(",");
					string ServerIPAddress;
					int ServerPortNumber;
					ServerIPAddress=ConfigurationDetail.substr(0,delimiter);
					string temp=ConfigurationDetail.substr(delimiter+1,ConfigurationDetail.size()-(delimiter+1));
					ServerPortNumber=atoi(temp.c_str());

					memset(&ServerAddress,0,sizeof(ServerAddress));
					ServerAddress.sin_family=AF_INET;
					ServerAddress.sin_port=htons(ServerPortNumber);
					ServerAddress.sin_addr.s_addr=inet_addr(ServerIPAddress.c_str());

					connect(SocketDescriptor,(struct sockaddr*)&ServerAddress,sizeof(ServerAddress));
				}
				else
				{
					int delimiter=ConfigurationDetail.find(",");
					devicedetail.ItemType=ConfigurationDetail.substr(0,delimiter);
					int delimiter2=ConfigurationDetail.find(",",delimiter+1,1);
					devicedetail.IpAddress=ConfigurationDetail.substr(delimiter+1,delimiter2-(delimiter+1));
					int delimiter3=ConfigurationDetail.find(",",delimiter2+1,1);
					devicedetail.PortNumber=ConfigurationDetail.substr(delimiter2+1,delimiter3-(delimiter2+1));

					string RegisterMessage="Type:Register;Action:"+devicedetail.ItemType+":"+devicedetail.IpAddress+":"+devicedetail.PortNumber;
					char s[1000];
					bzero(s,1001);
					strcpy(s,RegisterMessage.c_str());
					write(SocketDescriptor,s,strlen(s));
					ofstream displayfile;
					displayfile.open(ch,ios::out|ios::trunc);
					displayfile.close();


				}
			}


		}
		configfile.close();

				while(1)
				{
					cout<<"in data base"<<endl;

					char serverInstruction[1000];
					memset(&serverInstruction,0,1000);
					bzero(serverInstruction, 1001);
					int r=read(SocketDescriptor, serverInstruction, 1001);
					if(r>0)
					cout<<"read"<<endl;
					cout<<serverInstruction<<endl;
					string ServerInstruction(serverInstruction);

					ofstream displayfile;
					displayfile.open(ch,ios::out | ios::app);
					displayfile<<ServerInstruction<<endl;
					displayfile.close();




				}

			close (SocketDescriptor);

			return 0;


}
