#include <cstring>
#include <unistd.h>
#include <stdio.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <stdlib.h>
#include <string>
#include <time.h>
#include <pthread.h>
#include <ctime> //for timestamp

#define max 50  //max of 50 sensors can be connected

using namespace std;

struct DeviceDetail
{
	int ItemId;						// Assigning Thread ID
	string CurrentValue;			// Current Value
	string CurrentStatus;			// Current Status
	string IpAddress;				// IP Address of the client
	string PortNumber;				// Port number of the client
	string TypeOfItem;
	int Conndes;					// for storing the connection descriptor value
	string CurrentMsg;
	string CurrentTId;
};

int nTId;
bool dbFlag = false;
bool doorFlag = false;
bool kcFlag = false;
bool motionFlag = false;
bool ssFlag = false;
int Conndesarray[3];

time_t prevAliveTime = time(0);

char *ch;							//for storing 2nd argument from the command line
void motion(int);
void SmartDeviceMsg();
void *IOT(void *);
void outputfile(string);
string vectorclock;
void vectorrecv(int,int,int);
void databasefunc(string);
void * checkStatus(void *);
void forwardReq(int ItemId, string IpAddress, string PortNumber);
void handleCommit(string msg);
DeviceDetail * Device= new DeviceDetail[max];
pthread_t setval;
int ThreadNo=0;
int ConnectionDescriptor;
int SocketDescriptor;
stringstream Stream;
string ServerIpaddress;
int ServerPort;

int main(int argc, char *argv[])
{
	ch=argv[2];
	string ConfigDetails;
	struct sockaddr_in server,client;
	socklen_t ClientLength;
	int sock_desc;

	vectorclock="(0,0,0)";			//initializing gateway vector clock

	pthread_t Thread[max];			//initializing the thread
	pthread_t t2;

	ifstream ConfigFile (argv[1]);
	if(ConfigFile.is_open())
	{
		for(int Index=0;Index<1;Index++){

			getline(ConfigFile,ConfigDetails);
			if (Index==0){

				int delimiter=ConfigDetails.find(",");
				ServerIpaddress=ConfigDetails.substr(0,delimiter);
				string Temp=ConfigDetails.substr(delimiter+1,ConfigDetails.size()-(delimiter+1));
				ServerPort=atoi(Temp.c_str());
				Device[7].IpAddress = ServerIpaddress;
				Device[7].PortNumber = Temp;

			}
		}
	}

	ConfigFile.close();

	sock_desc=socket (AF_INET, SOCK_STREAM,0);
	memset(&server, 0, sizeof(server));
	server.sin_family = AF_INET;
	server.sin_addr.s_addr= inet_addr(ServerIpaddress.c_str());
	server.sin_port =  htons(ServerPort);

	if( bind(sock_desc,(struct sockaddr *)&server , sizeof(server)) < 0)
	{
		cout<<"bind failed. Error"<<endl;				//print the error message
		return 1;
	}
	else
		cout<<"bind done"<<endl;

	listen(sock_desc,20);
	cout<<"Gateway waiting for connections"<<endl;

	ofstream displayfile;
	displayfile.open(ch,ios::out|ios::trunc);
	displayfile.close();

	while(1)
	{
		cout<<"listening"<<endl;
		ClientLength=sizeof(client);
		ConnectionDescriptor=accept(sock_desc,(struct sockaddr *)&client,&ClientLength);
		if(ConnectionDescriptor<0)
		{
			cout<<"acceptfailed"<<endl;				//print the error message
			return 1;
		}
		else
			cout<<"connection accepted"<<endl;

		ThreadNo++;
		pthread_create(&Thread[ThreadNo - 1],NULL,IOT,(void*)&ConnectionDescriptor);
		//pthread_create(&t2,NULL,checkStatus,(void*)&sock_desc);

	}

	for(int i=0;i<ThreadNo;i++){
		pthread_join(Thread[i],NULL);
	}
	//pthread_join(t2,NULL);


	return 0;
}

void motion(int ID)
{
	int id=ID;
	string ItemType3 = "Door";
	int pos3=0;

	for(int Index = 0; Index <=50;Index++)
	{
		if(ItemType3.compare(Device[Index].TypeOfItem) == 0)
		{
			pos3=Index;						//index of device for that area
			break;
		}

	}

	string motionmsg = Device[pos3].IpAddress+";"+Device[pos3].PortNumber;	// Send Type:Switch;Action:off to the Device located at the AreaID of the Sensor
	int q=write(Device[id].Conndes ,motionmsg.c_str() ,strlen(motionmsg.c_str()));


}

void forwardReq(int ItemId, string IpAddress, string PortNumber){
	string newserver = "NEWSERVER:"+IpAddress+":"+PortNumber;
	int q = write(Device[ItemId].Conndes, newserver.c_str(), strlen(newserver.c_str()));
}

void *IOT(void *conndesc)							//function for receiving registering, current status, current value messages
{
	int client_sock=*(int*)conndesc;
	int ItemID=0;
	while(1)
	{
		char client_message[100];
		bzero(client_message, 101);
		string Compare;
		int n=recv(client_sock , client_message , 100 , 0);
		Stream<<nTId++;
		string TId=Stream.str();
		Stream.str("");
		TId = "T"+TId;
		cout << "Current TId: " << TId << endl;
		if ( n < 0)
		{
			cout<<"recv error \n"<<endl;
		}
		if(n== 0)
		{
			close (client_sock);
			break;
		}


		string devicedata(client_message);
		cout<<devicedata<<endl;

		if(devicedata.compare("ALIVE")==0){
			prevAliveTime = time(0);
			cout << endl<<"PrevAliveTime in primary gateway recv: " << prevAliveTime <<endl;
		} else if(devicedata.substr(0,devicedata.find(":")).compare("2PC")==0){
			outputfile(devicedata);
			int delimiter=devicedata.find(":")+1;
			int delimiter2=devicedata.find(":",delimiter,1);
			string TId=devicedata.substr(delimiter,delimiter2-delimiter);
			string msg = devicedata.substr(delimiter2+1,devicedata.size()-(delimiter2-1));
			string ItemId = msg.substr(0,1);
			Device[atoi(ItemId.c_str())].CurrentMsg = msg;
			Device[atoi(ItemId.c_str())].CurrentTId = TId;
			string yesM = "YES:"+TId;
			int q2 = write(SocketDescriptor,yesM.c_str(), strlen(yesM.c_str()));
			if (q2<=0){
				string abortM = "ABORT:"+TId;
				write(SocketDescriptor,abortM.c_str(), strlen(abortM.c_str()));
			}
		} else if(devicedata.substr(0,devicedata.find(":")).compare("VR")==0){
			outputfile(devicedata);
			int delimiter=devicedata.find(":")+1;
			string TId=devicedata.substr(delimiter);
			bool yesOK = false;
			for (int i = 1; i<=7; i++){
				yesOK = false;
				if (Device[i].CurrentTId == TId){
					string yesM = "YES:"+TId;
					int q2 = write(SocketDescriptor,yesM.c_str(), strlen(yesM.c_str()));
					if (q2>0){
						yesOK = true;
					}
					break;
				}
			}
			if (!yesOK){
				string abortM = "ABORT:"+TId;
				write(SocketDescriptor,abortM.c_str(), strlen(abortM.c_str()));
			}
		} else if(devicedata.substr(0,devicedata.find(":")).compare("YES")==0){
			outputfile(devicedata);
			int delimiter=devicedata.find(":")+1;
			string TId=devicedata.substr(delimiter);
			for (int i = 1; i<=7; i++){
				if (Device[i].CurrentTId == TId){
					string msg = Device[i].CurrentMsg;
					handleCommit(msg);
					break;
				}
			}
			string yesM = "COMMIT:"+TId;
			outputfile(yesM);
			int q2 = write(SocketDescriptor,yesM.c_str(), strlen(yesM.c_str()));
		} else if(devicedata.substr(0,devicedata.find(":")).compare("ABORT")==0){
			outputfile(devicedata);
			int delimiter=devicedata.find(":")+1;
			string TId=devicedata.substr(delimiter);
			for (int i = 1; i<=7; i++){
				if (Device[i].CurrentTId == TId){
					string msg = Device[i].CurrentMsg;
					outputfile(msg+"\n");
					cout << "Replication aborted: "+msg << endl;
					break;
				}
			}
		} else if(devicedata.substr(0,devicedata.find(":")).compare("COMMIT")==0){
			outputfile(devicedata);
			int delimiter=devicedata.find(":")+1;
			string TId=devicedata.substr(delimiter);
			for (int i = 1; i<=7; i++){
				if (Device[i].CurrentTId == TId){
					string msg = Device[i].CurrentMsg;
					handleCommit(msg);
					break;
				}
			}
		} else{
			int delimiter1=devicedata.find("Type:")+5;
			int delimiter2=devicedata.find(";Action:");
			Compare=devicedata.substr(delimiter1,delimiter2-delimiter1);

			if(Compare.compare("Register")==0)
			{
				int d3=devicedata.find(":",delimiter2+8,1);
				int d4=devicedata.find(":",d3+1,1);
				int d5=devicedata.find(":",d4+1,1);

				string typeofitem = devicedata.substr(delimiter2+8,d3-(delimiter2+8));
				if (typeofitem.compare("Database")==0){
					ItemID = 1;
				} else if (typeofitem.compare("secondarygateway")==0){
					cout << "Secondary gateway register message: " << devicedata << endl;
					ItemID = 2;
				} else if (typeofitem.compare("Door")==0){
					ItemID = 3;
				} else if (typeofitem.compare("Motion")==0){
					ItemID = 4;
				} else if (typeofitem.compare("Keychain")==0){
					ItemID = 5;
				} else if (typeofitem.compare("SecurityDevice")==0){
					ItemID = 6;
				}

				Device[ItemID].ItemId=ItemID;
				Device[ItemID].TypeOfItem=devicedata.substr(delimiter2+8,d3-(delimiter2+8));
				Device[ItemID].IpAddress=devicedata.substr(d3+1,d4-(d3+1));
				Device[ItemID].PortNumber=devicedata.substr(d4+1,d5-(d4+1));
				Device[ItemID].CurrentStatus = "off";
				Device[ItemID].CurrentValue = "";
				Device[ItemID].Conndes=client_sock;		//saving the connection descriptor value
				cout<<"type of item is "<<Device[ItemID].TypeOfItem<<endl;
				cout << "Connection Descriptor: " << Device[ItemID].Conndes << endl;

				if(Device[ItemID].TypeOfItem.compare("Motion")==0)
				{
					motionFlag = true;
					Conndesarray[0] = client_sock;
					cout<<"item id in motion register"<<ItemID<<endl;
					motion(ItemID);
				} else if(Device[ItemID].TypeOfItem.compare("Door")==0){
					doorFlag = true;
					Conndesarray[1] = client_sock;
				} else if(Device[ItemID].TypeOfItem.compare("Keychain")==0){
					forwardReq(5, Device[2].IpAddress, Device[2].PortNumber);
					sleep(3);
					kcFlag = true;
					Conndesarray[2] = client_sock;
				} else if(Device[ItemID].TypeOfItem.compare("SecurityDevice")==0){
					forwardReq(6, Device[2].IpAddress, Device[2].PortNumber);
					sleep(3);
					ssFlag = true;
				} else if(Device[ItemID].TypeOfItem.compare("Database")==0){
					dbFlag = true;
				}else if(Device[ItemID].TypeOfItem.compare("secondarygateway")==0){

					struct sockaddr_in ServerAddress;
					memset(&ServerAddress,0,sizeof(ServerAddress));
					ServerAddress.sin_family=AF_INET;
					ServerAddress.sin_port=htons(atoi(Device[ItemID].PortNumber.c_str()));
					ServerAddress.sin_addr.s_addr=inet_addr(Device[ItemID].IpAddress.c_str());
					SocketDescriptor=socket (AF_INET, SOCK_STREAM,0);
					connect(SocketDescriptor,(struct sockaddr*)&ServerAddress,sizeof(ServerAddress));
					string RegisterMessage="Type:Register;Action:primarygateway:"+ServerIpaddress+":"+Device[7].PortNumber;
					cout<<RegisterMessage<<endl;
					char s[1000];
					bzero(s,1001);
					strcpy(s,RegisterMessage.c_str());
					int q=write(SocketDescriptor,s,strlen(s));
					if(q<0){
						cout<<"send failed"<<endl;
					}
					outputfile(RegisterMessage);
				}

				if (doorFlag & motionFlag & kcFlag & ssFlag & dbFlag){
					for (int j=0; j<3; j++){
						string msg = "START";
						int q=write(Conndesarray[j] ,msg.c_str() ,strlen(msg.c_str()));
					}
				}

			}


			else if(Compare.compare("DoorState")==0)
			{
				int dem1=devicedata.find("Type:")+5;
				int dem2=devicedata.find(";Action")+7;
				int dem3=devicedata.find(":",dem2,1);
				int dem4=devicedata.find(";",dem3,1);
				int dem5=devicedata.find(":",dem4,1);
				int dem6=devicedata.find(";",dem5,1);
				int dem7=devicedata.find("(",dem6,1)+1;
				int dem8=devicedata.find(",",dem7,1)+1;
				int dem9=devicedata.find(",",dem8,1)+1;
				string temp1=devicedata.substr(dem7,dem8-dem7-1);
				string temp2=devicedata.substr(dem8,dem9-dem8-1);
				string temp3=devicedata.substr(dem9,strlen(devicedata.c_str())-dem9-1);
				Device[ItemID].CurrentValue=devicedata.substr(dem3+1,dem4-dem3-1);

				string vem="("+temp1+","+temp2+","+temp3+")";
				string th=devicedata.substr(dem5+1,dem6-dem5-1);
				Stream<<ItemID;
				string t=Stream.str();
				Stream.str("");
				string m=t+",Door,"+Device[ItemID].CurrentValue+","+th+","+vem+","+Device[ItemID].IpAddress+","+Device[ItemID].PortNumber;

				//2PC start
				Device[ItemID].CurrentMsg = m;
				Device[ItemID].CurrentTId = TId;
				string sendm = "2PC:"+TId+":"+m;
				outputfile(sendm);
				outputfile("Vote_request sent");
				int q1 = write(SocketDescriptor, sendm.c_str(), strlen(sendm.c_str()));
				//string vr = "VR:"+TId;
				//int q2 = write(SocketDescriptor, vr.c_str(), strlen(vr.c_str()));

				//2PC End

				//databasefunc(m);

				int a=atoi(temp1.c_str());
				int b=atoi(temp2.c_str());
				int c=atoi(temp3.c_str());
				vectorrecv(a,b,c);

				//SmartDeviceMsg();
			}

			else if(Compare.compare("MotionState")==0)
			{


				int dem1=devicedata.find("Type:")+5;
				int dem2=devicedata.find(";Action")+7;
				int dem3=devicedata.find(":",dem2,1);
				int dem4=devicedata.find(";",dem3,1);
				int dem5=devicedata.find(":",dem4,1);
				int dem6=devicedata.find(";",dem5,1);
				int dem7=devicedata.find("(",dem6,1)+1;
				int dem8=devicedata.find(",",dem7,1)+1;
				int dem9=devicedata.find(",",dem8,1)+1;
				string temp1=devicedata.substr(dem7,dem8-dem7-1);
				string temp2=devicedata.substr(dem8,dem9-dem8-1);
				string temp3=devicedata.substr(dem9,strlen(devicedata.c_str())-dem9-1);
				Device[ItemID].CurrentValue=devicedata.substr(dem3+1,dem4-dem3-1);
				string vem="("+temp1+","+temp2+","+temp3+")";
				string th=devicedata.substr(dem5+1,dem6-dem5-1);

				Stream<<ItemID;
				string t=Stream.str();
				Stream.str("");
				string m=t+",Motion,"+Device[ItemID].CurrentValue+","+th+","+vem+","+Device[ItemID].IpAddress+","+Device[ItemID].PortNumber;
				//2PC start
				Device[ItemID].CurrentMsg = m;
				Device[ItemID].CurrentTId = TId;
				string sendm = "2PC:"+TId+":"+m;
				outputfile(sendm);
				outputfile("Vote_request sent");
				int q1 = write(SocketDescriptor, sendm.c_str(), strlen(sendm.c_str()));
				//string vr = "VR:"+TId;
				//int q2 = write(SocketDescriptor, vr.c_str(), strlen(vr.c_str()));
				//2PC End

				//databasefunc(m);

				int a=atoi(temp1.c_str());
				int b=atoi(temp2.c_str());
				int c=atoi(temp3.c_str());
				vectorrecv(a,b,c);
				//SmartDeviceMsg();
			}
			else if(Compare.compare("KeychainState")==0)
			{

				int dem1=devicedata.find("Type:")+5;
				int dem2=devicedata.find(";Action")+7;
				int dem3=devicedata.find(":",dem2,1);
				int dem4=devicedata.find(";",dem3,1);
				int dem5=devicedata.find("(",dem3,1);
				int dem6=devicedata.find(",",dem4,1);
				int dem7=devicedata.find(",",dem5,1);
				Device[ItemID].CurrentValue=devicedata.substr(dem3+1,dem4-dem3-1);
				string ty=devicedata.substr(dem4+1,strlen(devicedata.c_str())-dem4);

				Stream<<ItemID;
				string t=Stream.str();
				Stream.str("");
				string m=t+",Keychain,"+Device[ItemID].CurrentValue+","+ty+","+Device[ItemID].IpAddress+","+ Device[ItemID].PortNumber;
				//2PC start
				Device[ItemID].CurrentMsg = m;
				Device[ItemID].CurrentTId = TId;
				string sendm = "2PC:"+TId+":"+m;
				outputfile(sendm);
				outputfile("Vote_request sent");
				int q1 = write(SocketDescriptor, sendm.c_str(), strlen(sendm.c_str()));
				//string vr = "VR:"+TId;
				//int q2 = write(SocketDescriptor, vr.c_str(), strlen(vr.c_str()));
				//2PC End
				/*databasefunc(m);
				SmartDeviceMsg();*/
			}


			else if(Compare.compare("currState")==0)
			{
				Device[ItemID].CurrentStatus=devicedata.substr(delimiter2+8,3);
				outputfile(devicedata);
			}
		}
		devicedata.clear();

	}
}

void handleCommit(string msg){
	int ItemId = atoi(msg.substr(0,1).c_str());
	cout <<"Writing to database: " << msg <<endl;
	databasefunc(msg);
	if (ItemId == 3){
		int dem1= msg.find(",");
		int dem2=msg.find(",",dem1+1,1);
		int dem3=msg.find(",",dem2+1,1);
		Device[3].CurrentValue = msg.substr(dem2+1,dem3-dem2-1);
		int dem4=msg.find("(")+1;
		int dem5=msg.find(",",dem4,1);
		int a=atoi(msg.substr(dem4,dem5-dem4).c_str());
		int dem6=msg.find(",",dem5+1,1);
		int b=atoi(msg.substr(dem5+1,dem6-dem5-1).c_str());
		int dem7=msg.find(")");
		int c=atoi(msg.substr(dem6+1,dem7-dem6-1).c_str());

		vectorrecv(a,b,c);
		SmartDeviceMsg();
	} else if (ItemId == 4){
		int dem1= msg.find(",");
		int dem2=msg.find(",",dem1+1,1);
		int dem3=msg.find(",",dem2+1,1);
		Device[4].CurrentValue = msg.substr(dem2+1,dem3-dem2-1);
		int dem4=msg.find("(")+1;
		int dem5=msg.find(",",dem4,1);
		int a=atoi(msg.substr(dem4,dem5-dem4).c_str());
		int dem6=msg.find(",",dem5+1,1);
		int b=atoi(msg.substr(dem5+1,dem6-dem5-1).c_str());
		int dem7=msg.find(")");
		int c=atoi(msg.substr(dem6+1,dem7-dem6-1).c_str());

		vectorrecv(a,b,c);
		SmartDeviceMsg();
	} else if (ItemId == 5){
		int dem1= msg.find(",");
		int dem2=msg.find(",",dem1+1,1);
		int dem3=msg.find(",",dem2+1,1);
		Device[5].CurrentValue = msg.substr(dem2+1,dem3-dem2-1);
		SmartDeviceMsg();
	}
}

void * checkStatus(void *){
	string alive = "ALIVE";
	sleep(30);
	while(1){
		sleep(10);
		cout << "Socket Descriptor: " <<SocketDescriptor << endl;
		int q = write(SocketDescriptor, alive.c_str(), strlen(alive.c_str()));
		cout<<"Difference in time: " << time(0)-prevAliveTime<<endl;
		if ((time(0) - prevAliveTime) > 13){
			outputfile("Switching secondary to primary gateway for keychain and security system.\n");
			cout << "Switching secondary to primary gateway for keychain and security system." << endl;
			//forwardReq(5, Device[7].IpAddress, Device[7].PortNumber);
			//forwardReq(6, Device[7].IpAddress, Device[7].PortNumber);
		}
	}
}

void vectorrecv(int x,int y,int z)
{
	int dem1=vectorclock.find("(")+1;
	int dem2=vectorclock.find(",")+1;
	int dem3=vectorclock.find(",",dem2,1)+1;
	string temp1=vectorclock.substr(dem1,dem2-dem1-1);
	string temp2=vectorclock.substr(dem2,dem3-dem2-1);
	string temp3=vectorclock.substr(dem3,strlen(vectorclock.c_str())-dem3-1);
	int a1=atoi(temp1.c_str());
	int a2=atoi(temp2.c_str());
	int a3=atoi(temp3.c_str());
	a3+=1;
	if(a1<x)
	{
		a1=x;
	}
	if(a2<y)
	{
		a2=y;
	}
	Stream << a1;
	temp1=Stream.str();
	Stream.str("");
	Stream<<a2;
	temp2=Stream.str();
	Stream.str("");
	Stream<<a3;
	temp3=Stream.str();
	Stream.str("");
	vectorclock="("+temp1+","+temp2+","+temp3+")";

}

void SmartDeviceMsg()
{
	string ItemType1 = "SecurityDevice";
	string ItemType2 = "Motion";
	string ItemType3 = "Door";
	string ItemType4 = "Keychain";
	string T="True";
	string O="Open";
	string F="False";
	string C="Close";
	int pos1=0,pos2=0,pos3=0,pos4=0;

	for(int Index = 0; Index <=50;Index++)
	{
		if(ItemType1.compare(Device[Index].TypeOfItem) == 0)
		{
			pos1=Index;						//index of device for that area
			break;
		}

	}

	for(int Index = 0; Index <=50;Index++)
	{
		if(ItemType2.compare(Device[Index].TypeOfItem) == 0)
		{
			pos2=Index;						//index of device for that area
			break;
		}

	}

	for(int Index = 0; Index <=50;Index++)
	{
		if(ItemType3.compare(Device[Index].TypeOfItem) == 0)
		{
			pos3=Index;						//index of device for that area
			break;
		}

	}

	for(int Index = 0; Index <=50;Index++)
	{
		if(ItemType4.compare(Device[Index].TypeOfItem) == 0)
		{
			pos4=Index;						//index of device for that area
			break;
		}

	}

	if(pos1!=0 && pos2!=0 && pos3!=0 && pos4!=0)
	{
		int dem1=vectorclock.find("(")+1;
		int dem2=vectorclock.find(",")+1;
		int dem3=vectorclock.find(",",dem2,1)+1;
		string temp1=vectorclock.substr(dem1,dem2-dem1-1);
		string temp2=vectorclock.substr(dem2,dem3-dem2-1);
		string temp3=vectorclock.substr(dem3,strlen(vectorclock.c_str())-dem3-1);
		int a1=atoi(temp1.c_str());
		int a2=atoi(temp2.c_str());
		int a3=atoi(temp3.c_str());

		cout<<a1<<endl<<a2<<endl;

		cout<<Device[pos2].CurrentValue<<endl<<Device[pos3].CurrentValue<<endl;

		string mv =(Device[pos2].CurrentValue.c_str());
		string dv=(Device[pos3].CurrentValue.c_str());
		string kv=(Device[pos4].CurrentValue.c_str());

		Stream<<mv;
		string mtn=Stream.str();
		Stream.str("");
		Stream<<dv;
		string dov=Stream.str();
		Stream.str("");
		Stream<<kv;
		string kev=Stream.str();
		Stream.str("");



		if(a1<a2)
		{
			if(T.compare(mtn)==0 && O.compare(dov)==0)
			{



				if(T.compare(kev)==0)
				{
					string usermsg="user entered room";
					outputfile(usermsg);

					if(Device[pos1].CurrentStatus.compare("off")!=0)		//checking with smart device;
					{
						string ServerMessage = "Type:Switch;Action:off";	// Send Type:Switch;Action:off to the Device located at the AreaID of the Sensor
						int q=write(Device[pos1].Conndes ,ServerMessage.c_str() ,strlen(ServerMessage.c_str()));
						outputfile(ServerMessage);
						if(q<0)
							cout<<"unable to write"<<endl;				//print error message
						Device[pos1].CurrentStatus="off";
						Stream<<pos1;
						string t=Stream.str();
						Stream.str("");
						time_t now=time(0);
						Stream<<now;
						string tm=Stream.str();
						Stream.str("");
						string m=t+", SecuritySystem , off , "+tm+" , "+vectorclock+" , "+Device[pos1].IpAddress+" , "+Device[pos1].PortNumber;
						Stream<<nTId++;
						string TId=Stream.str();
						Stream.str("");
						TId = "T"+TId;
						Device[pos1].CurrentTId = TId;
						Device[pos1].CurrentMsg = m;
						string sendm = "2PC:"+TId+":"+m;
						int q1 = write(SocketDescriptor, sendm.c_str(), strlen(sendm.c_str()));
						//string vr = "VR:"+TId;
						//int q2 = write(SocketDescriptor, vr.c_str(), strlen(vr.c_str()));
						//databasefunc(m);
					}
				}
				else if(F.compare(kev)==0 && Device[pos1].CurrentStatus.compare("on")==0)
				{

					string urmsg="intruder entered and alaram is raised";
					outputfile(urmsg);
					cout<<"ALARAM RAISED"<<endl;

				}
			}
		}
		else if(a1>a2)
		{

			if(T.compare(mtn)==0 && C.compare(dov)==0)
			{
				string usrmsg="user exited room";
				outputfile(usrmsg);
				if(Device[pos1].CurrentStatus.compare("on") != 0)		//checking with smart device;
				{
					string ServerMessage = "Type:Switch;Action:on";	// Send Type:Switch;Action:off to the Device located at the AreaID of the Sensor
					int q=write(Device[pos1].Conndes ,ServerMessage.c_str() ,strlen(ServerMessage.c_str()));
					outputfile(ServerMessage);
					if(q<0)
						cout<<"unable to write"<<endl;				//print error message
					Device[pos1].CurrentStatus="on";
					Stream<<pos1;
					string t=Stream.str();
					Stream.str("");
					time_t now=time(0);
					Stream<<now;
					string tm=Stream.str();
					Stream.str("");
					string m=t+", SecuritySystem , on , "+tm+" , "+vectorclock+" , "+Device[pos1].IpAddress+" , "+Device[pos1].PortNumber;
					Stream<<nTId++;
					string TId=Stream.str();
					Stream.str("");
					TId = "T"+TId;
					Device[pos1].CurrentTId = TId;
					Device[pos1].CurrentMsg = m;
					string sendm = "2PC:"+TId+":"+m;
					int q1 = write(SocketDescriptor, sendm.c_str(), strlen(sendm.c_str()));
					//string vr = "VR:"+TId;
					//int q2 = write(SocketDescriptor, vr.c_str(), strlen(vr.c_str()));
					//databasefunc(m);
				}
			}
		}
	}
}

void databasefunc(string s)
{

	string ServerMesg = s;	// Send Type:Switch;Action:off to the Device located at the AreaID of the Sensor
	cout<<"Device[1].Conndes : " << Device[1].Conndes << ", Message Sent: " << ServerMesg<<endl;
	int q=write(Device[1].Conndes ,ServerMesg.c_str() ,strlen(ServerMesg.c_str()));


}


void outputfile(string msg)
{
	ofstream outputFile;
	outputFile.open(ch,ios::out | ios::app);
	outputFile<<msg<<" logged by gateway"<<endl;
	outputFile.close();
}
