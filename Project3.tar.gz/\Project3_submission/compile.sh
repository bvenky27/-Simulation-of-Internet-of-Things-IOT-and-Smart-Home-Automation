#!/bin/bash
g++ -g src/Gateway/gateway.cpp -lpthread -o output/gateway
g++ -g src/SecondaryGateway/secondaryGateway.cpp -lpthread -o output/sgateway
g++ -g src/Door/door.cpp -lpthread -o output/door
g++ -g src/Motion/motion.cpp -lpthread -o output/motion
g++ -g src/KeyChain/keychain.cpp -lpthread -o output/keychain
g++ -g src/SecuritySystem/securitysystem.cpp -lpthread -o output/securitysystem
g++ -g src/Database/database.cpp -lpthread -o output/database
