IMPORTANT NOTE:
First run Gateway.cpp.
After Gateway.cpp, run Door.cpp
After door.cpp, run Motion.cpp
After motion.cpp, run other files such as Keychain.cpp,SecuritySystem.cpp and Database.cpp

enter 1 in each of the Door.cpp, Motion.cpp, Keychain.cpp for those sensors to start running after the registration of all sensors and devices.

1. In this project we have assumed that user will be at home at the beginning... when the user exits the home then he turns on the security system as mentioned in the instructions.
2. we have assumed that when the motion "True" event happens first and then door "Close" event happens next then it is an event where user exits the room and he turns the security system "on" irresepective of the value of the keychain.(the assumption was made after observing the results in the SamplePersistentstorageFile which is attached with project details)
3. when the door "Open" event happens first and then the motion "True" event happens next then it is taken as users entered home event and here if the keychain sensor is "True" then the security system is turned "off" else if keychain value is "False" then it is taken as intruder event and the alarm is turned on.

GATEWAY PROGRAM:
To run this program one has to enter the configuration file and also the output file.
For example one can run it via ./gateway GatewayConfigurationFile.txt Output.txt

DOOR PROGRAM:
To run this program one has to enter the configuration file, state file and also the output file.
For example one can run it via ./door DoorConfigurationFile.txt DoorStateFile.txt Output.txt

MOTION PROGRAM:
To run this program one has to enter the configuration file, state file and also the output file.
For example one can run it via ./motion MotionSensorConfigurationFile.txt MotionSensorStateFile.txt Output.txt

KEYCHAIN PROGRAM:
To run this program one has to enter the configuration file, state file and also the output file.
For example one can run it via ./keychain KeyChainConfigurationFile.txt KeyChainStateFile.txt Output.txt

SECURITY SYSTEM PROGRAM:
To run this program one has to enter the configuration file and also the output file.
For example one can run it via ./securitysystem SecuritySystemConfigurationFile.txt Output.txt

DATABASE PROGRAM:
To run this program one has to enter the configuration file and also the output file.
For example one can run it via ./database BackEndConfigurationFile.txt PersistentStorageFile.txt

in the sampleoutputfiles we included our test run results.



