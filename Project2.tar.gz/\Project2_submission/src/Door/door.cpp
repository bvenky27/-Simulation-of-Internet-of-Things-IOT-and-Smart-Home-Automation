#include <cstring>
#include <unistd.h>
#include <stdio.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <stdlib.h>
#include <string>
#include <time.h>
#include <pthread.h>
#include <ctime>

using namespace std;

struct DeviceDetail
{
	string ItemType;
	string IpAddress;
	string PortNumber;
	string CurrentState;
};

char *ch,*ch1;

string vectorclock;
void outputfile(string);
void *Time(void *);
void *Receive(void*);
void vectorrecv(int);
void vectorsend();
DeviceDetail devicedetail;

int SocketDescriptor;
int MyListenDescriptor, ConnectionDescriptor;
stringstream Stream;


int main(int argc, char *argv[])
{
	ch=argv[3];
	ch1=argv[2];
	string ConfigurationDetail;				// To hold data from the configuration file passed on to the Client program as command line argument
	struct sockaddr_in ServerAddress, MyAddress, client;
	socklen_t ClientLength;
	SocketDescriptor = socket(AF_INET, SOCK_STREAM,0);
	vectorclock="(0,0,0)";

	pthread_t TaskThread,t1;

	ifstream configfile (argv[1]);				//open the above mentioned Device Configuration File and read the file
		if(configfile.is_open())
		{
			for(int Index=0;Index<2;Index++)
			{
				getline(configfile,ConfigurationDetail);

				if(Index==0)				//if its in first line of the file
				{
					int delimiter=ConfigurationDetail.find(",");
					string ServerIPAddress;
					int ServerPortNumber;
					ServerIPAddress=ConfigurationDetail.substr(0,delimiter);
					string temp=ConfigurationDetail.substr(delimiter+1,ConfigurationDetail.size()-(delimiter+1));
					ServerPortNumber=atoi(temp.c_str());

					memset(&ServerAddress,0,sizeof(ServerAddress));
					ServerAddress.sin_family=AF_INET;
					ServerAddress.sin_port=htons(ServerPortNumber);
					ServerAddress.sin_addr.s_addr=inet_addr(ServerIPAddress.c_str());

					connect(SocketDescriptor,(struct sockaddr*)&ServerAddress,sizeof(ServerAddress));
				}
				else
				{
					int delimiter=ConfigurationDetail.find(",");
					devicedetail.ItemType=ConfigurationDetail.substr(0,delimiter);
					int delimiter2=ConfigurationDetail.find(",",delimiter+1,1);
					devicedetail.IpAddress=ConfigurationDetail.substr(delimiter+1,delimiter2-(delimiter+1));
					devicedetail.PortNumber=ConfigurationDetail.substr(delimiter2+1,ConfigurationDetail.size()-(delimiter2+1));
					int MyPortNumber=atoi(devicedetail.PortNumber.c_str());


					string RegisterMessage="Type:Register;Action:"+devicedetail.ItemType+":"+devicedetail.IpAddress+":"+devicedetail.PortNumber;
					char s[1000];
					bzero(s,1001);
					strcpy(s,RegisterMessage.c_str());
					write(SocketDescriptor,s,strlen(s));
					outputfile(RegisterMessage);

					memset(&MyAddress, 0, sizeof(MyAddress));
					MyAddress.sin_family=AF_INET;
					MyAddress.sin_addr.s_addr=inet_addr(devicedetail.IpAddress.c_str());
					MyAddress.sin_port=htons(MyPortNumber);
					MyListenDescriptor=socket(AF_INET,SOCK_STREAM,0);

					int h=bind(MyListenDescriptor,(struct sockaddr *)&MyAddress,sizeof(MyAddress));
					if (h<0)
					{
						cout<<"bind failed"<<endl;
						return 1;
					}
					listen(MyListenDescriptor,3);

					cout<<"Door waiting for connections"<<endl;

					ClientLength=sizeof(client);
					ConnectionDescriptor=accept(MyListenDescriptor,(struct sockaddr *)&client,&ClientLength);
					if(ConnectionDescriptor<0)
					{
						cout<<"acceptfailed"<<endl;
						return 1;
					}
					else
					{
						cout<<"connection accepted"<<endl;
					}

							pthread_create(&TaskThread,NULL,Receive,(void*)&ConnectionDescriptor);
							pthread_create(&t1,NULL,Time, (void*)&SocketDescriptor);

				}
			}

			configfile.close();
		}
		pthread_join(TaskThread,NULL);
		pthread_join(t1,NULL);



}

void *Time (void * socketDescriptor)
{
	int serverSocketDescriptor = * (int *)socketDescriptor;
	int i,a=0,d1,d2;
	string check;
	cout<<"enter 1 to start the door sensor"<<endl;
	cin>>i;
	while(1)
	{
		ifstream timefile(ch1);
		if (timefile.is_open())
		{
			cout<<"reading door sensor state file"<<endl;
			while(!timefile.eof())
			{

				string state;
				getline(timefile,state);
				d1=state.find(";");
				check=state.substr(d1+1,1);
				if (check.compare("O")==0)
				{
					check="Open";
				}
				else
				{
					check="Close";
				}

				string tempst=state.substr(0,d1);
				int StartTime=atoi(tempst.c_str());

				sleep(StartTime);

				time_t now=time(0);
				Stream<<now;
				string temp=Stream.str();
				Stream.str("");


				vectorsend();

				string ValueMessage="Type:DoorState;Action:"+check+";Timestamp:"+temp+";vector:"+vectorclock;
				cout<<check<<endl;
				char u[100];
				bzero(u,1001);
				strcpy(u,ValueMessage.c_str());
				send(serverSocketDescriptor, u, strlen(ValueMessage.c_str()),0);
				send(ConnectionDescriptor ,ValueMessage.c_str() ,strlen(ValueMessage.c_str()),0);
				outputfile(ValueMessage);



			}

		}
		timefile.close();

	}

}

void *Receive (void * conndes)
{
	cout<<"in receive function"<<endl;
	int client_sock=*(int*)conndes;
	while(1)
	{
		char client_message[1000];
		bzero (client_message,1001);
		int n=recv(ConnectionDescriptor, client_message,100,0);
		if(n<0)
		{
			cout<<"recv error"<<endl;

		}
		if(n==0)
		{
			close(client_sock);
			break;
		}
		string motionvector(client_message);
		cout<<motionvector<<endl;
		int dem1=motionvector.find("(")+1;
		int dem2=motionvector.find(",")+1;
		int dem3=motionvector.find(",",dem2,1)+1;
		string temp1=motionvector.substr(dem1,dem2-dem1-1);
		string temp2=motionvector.substr(dem2,dem3-dem2-1);
		string temp3=motionvector.substr(dem3,strlen(motionvector.c_str())-dem3-1);
		int b1=atoi(temp1.c_str());
		int b2=atoi(temp2.c_str());
		int b3=atoi(temp3.c_str());

		vectorrecv(b2);
	}

}

void vectorsend()
{

		int dem1=vectorclock.find("(")+1;
		int dem2=vectorclock.find(",")+1;
		int dem3=vectorclock.find(",",dem2,1)+1;
		string temp1=vectorclock.substr(dem1,dem2-dem1-1);
		string temp2=vectorclock.substr(dem2,dem3-dem2-1);
		string temp3=vectorclock.substr(dem3,strlen(vectorclock.c_str())-dem3-1);
		int a1=atoi(temp1.c_str());
		int a2=atoi(temp2.c_str());
		int a3=atoi(temp3.c_str());
		a1+=1;
		Stream << a1;
		temp1= Stream.str();
		Stream.str("");
		vectorclock="("+temp1+","+temp2+","+temp3+")";

}

void vectorrecv(int b)
{
	int dem1=vectorclock.find("(")+1;
	int dem2=vectorclock.find(",")+1;
	int dem3=vectorclock.find(",",dem2,1)+1;
	string temp1=vectorclock.substr(dem1,dem2-dem1-1);
	string temp2=vectorclock.substr(dem2,dem3-dem2-1);
	string temp3=vectorclock.substr(dem3,strlen(vectorclock.c_str())-dem3-1);
	int a1=atoi(temp1.c_str());
	int a2=atoi(temp2.c_str());
	int a3=atoi(temp3.c_str());
	a1+=1;
	Stream << a1;
	temp1= Stream.str();
	Stream.str("");
	a2=b;
	Stream << a2;
	temp2=Stream.str();
	Stream.str("");
	vectorclock="("+temp1+","+temp2+","+temp3+")";
	cout<<"received "<<vectorclock<<endl;

}
void outputfile(string msg)
{
	ofstream outputFile;
	outputFile.open(ch,ios::out | ios::app);
	outputFile<<msg<<" sent by door sensor"<<endl;
	outputFile.close();
}
