#include <cstring>
#include <unistd.h>
#include <stdio.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <stdlib.h>
#include <string>
#include <time.h>
#include <pthread.h>
#include <ctime>

using namespace std;

struct DeviceDetail
{
	string ItemType;
	string IpAddress;
	string PortNumber;
	string CurrentState;
};

char *ch,*ch1;
int Interval=5;
void outputfile(string);
void *Time(void *);
DeviceDetail devicedetail;
stringstream Stream;

int SocketDescriptor;

int main(int argc, char *argv[])
{
	ch=argv[3];
	ch1=argv[2];
	string ConfigurationDetail;				// To hold data from the configuration file passed on to the Client program as command line argument
	struct sockaddr_in ServerAddress, MyAddress;
	SocketDescriptor = socket(AF_INET, SOCK_STREAM,0);
	int MyListenDescriptor;
	pthread_t TaskThread;

	ifstream configfile (argv[1]);				//open the above mentioned Device Configuration File and read the file
		if(configfile.is_open())
		{
			for(int Index=0;Index<2;Index++)
			{
				getline(configfile,ConfigurationDetail);

				if(Index==0)				//if its in first line of the file
				{
					int delimiter=ConfigurationDetail.find(",");
					string ServerIPAddress;
					int ServerPortNumber;
					ServerIPAddress=ConfigurationDetail.substr(0,delimiter);
					string temp=ConfigurationDetail.substr(delimiter+1,ConfigurationDetail.size()-(delimiter+1));
					ServerPortNumber=atoi(temp.c_str());

					memset(&ServerAddress,0,sizeof(ServerAddress));
					ServerAddress.sin_family=AF_INET;
					ServerAddress.sin_port=htons(ServerPortNumber);
					ServerAddress.sin_addr.s_addr=inet_addr(ServerIPAddress.c_str());

					connect(SocketDescriptor,(struct sockaddr*)&ServerAddress,sizeof(ServerAddress));
				}
				else
				{
					int delimiter=ConfigurationDetail.find(",");
					devicedetail.ItemType=ConfigurationDetail.substr(0,delimiter);
					int delimiter2=ConfigurationDetail.find(",",delimiter+1,1);
					devicedetail.IpAddress=ConfigurationDetail.substr(delimiter+1,delimiter2-(delimiter+1));
					devicedetail.PortNumber=ConfigurationDetail.substr(delimiter2+1,ConfigurationDetail.size()-(delimiter2+1));

					string RegisterMessage="Type:Register;Action:"+devicedetail.ItemType+":"+devicedetail.IpAddress+":"+devicedetail.PortNumber;
					char s[1000];
					bzero(s,1001);
					strcpy(s,RegisterMessage.c_str());
					write(SocketDescriptor,s,strlen(s));
					outputfile(RegisterMessage);
					pthread_create(&TaskThread, NULL, Time, (void*) &SocketDescriptor);

				}
			}

			configfile.close();
		}
		pthread_join(TaskThread,NULL);




}

void *Time (void * socketDescriptor)
{
	int serverSocketDescriptor = * (int *)socketDescriptor;
	int i,a=0,d1,d2;
	cout<<"enter 1 to start the key chain sensor"<<endl;
	cin>>i;
	cout<<"reading key chain sensor state file"<<endl;
	while(i)
	{

		ifstream timefile(ch1);
		if (timefile.is_open())
		{

			while(!timefile.eof())
			{
				string state;
				getline(timefile,state);
				d1=state.find(";");
				d2=state.find(";",d1+1,1);
				int d3= state.find("e",d2,1);
				string tempst=state.substr(0,d1);
				int StartTime=atoi(tempst.c_str());
				string tempend=state.substr(d1+1,d2-(d1+1));
				int EndTime=atoi(tempend.c_str());
				int difference=EndTime-StartTime;
				if(Interval!=0)
				{

					difference=difference-a;
					a=difference-Interval;
					while(a>=Interval)
					{
						if(a>=Interval)
						{
							sleep(Interval);
							a=a-Interval;
						}


						time_t now=time(0);
						Stream<<now;
						string temp=Stream.str();
						Stream.str("");

						string ValueMessage="Type:KeychainState;Action:"+state.substr(d2+1,(d3-(d2)))+";"+temp;
						char u[100];
						bzero(u,1001);
						strcpy(u,ValueMessage.c_str());
						send(serverSocketDescriptor, u, strlen(ValueMessage.c_str()),0);
						outputfile(ValueMessage);
					}
				}

			}

		}
		timefile.close();

	}

}

void outputfile(string msg)
{
	ofstream outputFile;
	outputFile.open(ch,ios::app);
	outputFile<<msg<<" logged by keychain sensor"<<endl;
	outputFile.close();
}
