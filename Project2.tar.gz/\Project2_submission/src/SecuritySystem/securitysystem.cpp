#include <cstring>
#include <unistd.h>
#include <stdio.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <stdlib.h>
#include <string>
#include <time.h>
#include <pthread.h>
#include <ctime>

using namespace std;

struct DeviceDetail
{
	string ItemType;
	string IpAddress;
	string PortNumber;
	string CurrentState;
};

char *ch;
void outputfile(string);
DeviceDetail devicedetail;

int SocketDescriptor;

int main(int argc, char *argv[])
{
	ch=argv[2];
	string ConfigurationDetail;				// To hold data from the configuration file passed on to the Client program as command line argument
	struct sockaddr_in ServerAddress, MyAddress;
	SocketDescriptor = socket(AF_INET, SOCK_STREAM,0);
	int MyListenDescriptor;
	pthread_t TaskThread;

	ifstream configfile (argv[1]);				//open the above mentioned Device Configuration File and read the file
		if(configfile.is_open())
		{
			for(int Index=0;Index<2;Index++)
			{
				getline(configfile,ConfigurationDetail);

				if(Index==0)				//if its in first line of the file
				{
					int delimiter=ConfigurationDetail.find(",");
					string ServerIPAddress;
					int ServerPortNumber;
					ServerIPAddress=ConfigurationDetail.substr(0,delimiter);
					string temp=ConfigurationDetail.substr(delimiter+1,ConfigurationDetail.size()-(delimiter+1));
					ServerPortNumber=atoi(temp.c_str());

					memset(&ServerAddress,0,sizeof(ServerAddress));
					ServerAddress.sin_family=AF_INET;
					ServerAddress.sin_port=htons(ServerPortNumber);
					ServerAddress.sin_addr.s_addr=inet_addr(ServerIPAddress.c_str());

					connect(SocketDescriptor,(struct sockaddr*)&ServerAddress,sizeof(ServerAddress));
				}
				else
				{
					int delimiter=ConfigurationDetail.find(",");
					devicedetail.ItemType=ConfigurationDetail.substr(0,delimiter);
					int delimiter2=ConfigurationDetail.find(",",delimiter+1,1);
					devicedetail.IpAddress=ConfigurationDetail.substr(delimiter+1,delimiter2-(delimiter+1));
					devicedetail.PortNumber=ConfigurationDetail.substr(delimiter2+1,ConfigurationDetail.size()-(delimiter2+1));

					string RegisterMessage="Type:Register;Action:"+devicedetail.ItemType+":"+devicedetail.IpAddress+":"+devicedetail.PortNumber;
					char s[1000];
					bzero(s,1001);
					strcpy(s,RegisterMessage.c_str());
					write(SocketDescriptor,s,strlen(s));
					outputfile(RegisterMessage);

				}
			}


		}
		configfile.close();
		devicedetail.CurrentState = "on";
				while(1)
				{
					cout<<"in status check"<<endl;
					bool IsStateChange = false;
					char serverInstruction[1000];
					memset(&serverInstruction,0,1000);
					bzero(serverInstruction, 1001);
					int r=read(SocketDescriptor, serverInstruction, 1001);
					if(r>0)
					cout<<"read"<<endl;
					cout<<serverInstruction<<endl;
					string ServerInstruction(serverInstruction);
					outputfile(ServerInstruction);
					if(ServerInstruction.compare("Type:Switch;Action:on") == 0)
					{	cout<<"on"<<endl;
						devicedetail.CurrentState = "on";
						IsStateChange = true;
					}
					else if(ServerInstruction.compare("Type:Switch;Action:off") == 0)
					{	cout<<"off"<<endl;
						devicedetail.CurrentState = "off";
						IsStateChange = true;
					}

					if(IsStateChange)
					{
						cout<<"sending the current state"<<endl;
						string StatusMessage = "Type:SecuritySystemState;Action:" + devicedetail.CurrentState;
						send(SocketDescriptor, StatusMessage.c_str(),strlen(StatusMessage.c_str()),0);
						outputfile(StatusMessage);
					}
				}

			close (SocketDescriptor);

			return 0;


}

void outputfile(string msg)
{
	ofstream outputFile;
	outputFile.open(ch,ios::app);
	outputFile<<msg<< " logged by security system"<<endl;
	outputFile.close();
}
