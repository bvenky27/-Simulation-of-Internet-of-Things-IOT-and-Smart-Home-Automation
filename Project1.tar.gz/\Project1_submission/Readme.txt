1.**IMPORTANT:Once gateway code is compiled and run then first compile and run the device code after which compile and run the sensor code. 
If one run the sensor code first one has to immediately run the device code then only it will work else it will show segmentation fault because by the time device code starts executing sensor code reaches display function.
So its better to run device code first then sensor code. 

2.DEVICE PROGRAM:
To run Device program  while you compile the program one has to enter the device configuration file name to run the program.

For example one can run it via ./device DeviceConfigurationFile.txt or ./device DeviceConfiguration2.txt

3.SENSOR PROGRAM:
To run Sensor program  while you compile the program one has to enter the sensor configuration file and sensor input file names to run the program. 

For example one can run it via ./sensor SensorConfigurationFile1.txt or ./sensor SensorConfiguration2.txt or ./sensor SensorConfiguration3.txt or ./sensor SensorConfiguration4.txt inputs file name as SensorInputFile1.txt or SensorInputFile2.txt or SensorInputFile3.txt or SensorInputFile4.txt

4.GATEWAY PROGRAM:
Once gateway, device and sensor file are run, there is a command prompt on the gateway screen stating the "enter the set value interval". If you want to eneter the set value one can enter the value or else leave it blank.
5.See the onput in GatewayDisplay.txt