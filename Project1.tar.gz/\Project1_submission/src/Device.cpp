#include <cstring>
#include <unistd.h>
#include <stdio.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <stdlib.h>
#include <string>
#include <time.h>

using namespace std;

struct MyDetail
{
	string ItemType;					// Assigning Item type
	string AreaID;						// Device provided AreaID
	string CurrentState;					// Current Status (common for both sensor and device)
	string CurrentValue;					// Current Value (only Sensor provides this data)
	string MyIPAddress;					// IP Address of the device
	string MyPortNumber;					// Port number of the device
};

MyDetail myDetail;
int INTERVAL;
void Temp(string);
string TemparatureDetail;
int ServerSocketDescriptor;


int main(int argc, char *argv[])
{
	string ConfigurationDetail;				// To hold data from the configuration file passed on to the Client program as command line argument
    	struct sockaddr_in ServerAddress, MyAddress;
	ServerSocketDescriptor = socket(AF_INET, SOCK_STREAM,0);
	int MyListenDescriptor;
	pthread_t TaskThread;
	INTERVAL;
	//cout<<"enter the name of DeviceConfigurationFile"<<endl;
	


	ifstream configfile (argv[1]);				//open the above mentioned Device Configuration File and read the file
	if(configfile.is_open())
	{
		for(int Index=0;Index<2;Index++)
		{
			getline(configfile,ConfigurationDetail);

			if(Index==0)				//if its in first line of the file
			{
				int delimiter=ConfigurationDetail.find(":");
				string ServerIPAddress;
				int ServerPortNumber;
				ServerIPAddress=ConfigurationDetail.substr(0,delimiter);
				string temp=ConfigurationDetail.substr(delimiter+1,ConfigurationDetail.size()-(delimiter+1));
				ServerPortNumber=atoi(temp.c_str());

				memset(&ServerAddress,0,sizeof(ServerAddress));
				ServerAddress.sin_family=AF_INET;
				ServerAddress.sin_port=htons(ServerPortNumber);
				ServerAddress.sin_addr.s_addr=inet_addr(ServerIPAddress.c_str());

				connect(ServerSocketDescriptor,(struct sockaddr*)&ServerAddress,sizeof(ServerAddress));
			}
			else
			{
				int delimiter=ConfigurationDetail.find(":");
				myDetail.ItemType=ConfigurationDetail.substr(0,delimiter);
				int delimiter2=ConfigurationDetail.find(":",delimiter+1,1);
				myDetail.MyIPAddress=ConfigurationDetail.substr(delimiter+1,delimiter2-(delimiter+1));
				int delimiter3=ConfigurationDetail.find(":",delimiter2+1,1);
				myDetail.MyPortNumber=ConfigurationDetail.substr(delimiter2+1,delimiter3-(delimiter2+1));
				myDetail.AreaID=ConfigurationDetail.substr(delimiter3+1,ConfigurationDetail.size()-(delimiter3+1));

				string RegisterMessage="Type:Register;Action:"+myDetail.ItemType+":"+myDetail.MyIPAddress+":"+myDetail.MyPortNumber+":"+myDetail.AreaID;
				char s[1000];
				bzero(s,1001);
				strcpy(s,RegisterMessage.c_str());
				write(ServerSocketDescriptor,s,strlen(s));
			}	
		}

		configfile.close();
	}

	myDetail.CurrentState = "on";
		while(1)
		{       
			cout<<"in status check"<<endl;
			bool IsStateChange = false;
			char serverInstruction[1000];
			memset(&serverInstruction,0,1000);
			bzero(serverInstruction, 1001);
			int r=read(ServerSocketDescriptor, serverInstruction, 1001);
			if(r>0)
			cout<<"read"<<endl;
			cout<<serverInstruction<<endl;	
			string ServerInstruction(serverInstruction);
			if(ServerInstruction.compare("Type:Switch;Action:on") == 0)
			{	cout<<"on"<<endl;
				myDetail.CurrentState = "on";
				IsStateChange = true;
			}
			else if(ServerInstruction.compare("Type:Switch;Action:off") == 0)
			{	cout<<"off"<<endl;
				myDetail.CurrentState = "off";
				IsStateChange = true;
			}
			
			if(IsStateChange)
			{
				cout<<"sending the current state"<<endl;
				string StatusMessage = "Type:currState;Action:" + myDetail.CurrentState;
			}
		}

	close (ServerSocketDescriptor);	

	return 0;
}
