#include <cstring>
#include <unistd.h>
#include <stdio.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <stdlib.h>
#include <string>
#include <time.h>
#include <pthread.h>

#define max 50

using namespace std;

struct DeviceDetail
{
	int ItemId;					// Assigning Thread ID
	string AreaId;					// Sensor/Device provided AreaID
	string CurrentValue;				// Current Value (only Sensor provides this data)
	string CurrentStatus;				// Current Status (common for both sensor and device)
	string IpAddress;				// IP Address of the client
	string PortNumber;				// Port number of the client
	string TypeOfItem;				// Either Sensor OR Device
	int Conndes;
};

void SmartDeviceMsg(int);
void *IOT(void *);
void DisplayCurrentState(int);
void *setvalfunction(void*);

DeviceDetail * Device= new DeviceDetail[max];
pthread_t setval;
int ThreadNo=0;
//int SocketDescriptor;
int ConnectionDescriptor;

void *setvalfunction(void *des )
{	
	char d;
	int df=*(int*)des;
	cout<<"enter the set interval value if needed:"<<endl;
 	string message;
	cin >>d;
	message=d;
	char j[1000];
        bzero(j,1001);
	strcpy(j,message.c_str());
	send(df, j, 1000 , 0);
}

int main(int argc, char *argv[])
{
	string ConfigDetails;
	struct sockaddr_in server,client;
	socklen_t ClientLength;
	int sock_desc;
	string ServerIpaddress;
	int ServerPort;

	pthread_t Thread[max];

	ifstream ConfigFile (argv[1]);
	if(ConfigFile.is_open())
	{
		while(getline(ConfigFile,ConfigDetails))
		{
			int delimiter=ConfigDetails.find(":");
			ServerIpaddress=ConfigDetails.substr(0,delimiter);
			string Temp=ConfigDetails.substr(delimiter+1,ConfigDetails.size()-(delimiter+1));
			ServerPort=atoi(Temp.c_str());
		}
		ConfigFile.close();
	}
	sock_desc=socket (AF_INET, SOCK_STREAM,0);
    	memset(&server, 0, sizeof(server));
	server.sin_family = AF_INET;
	server.sin_addr.s_addr= inet_addr(ServerIpaddress.c_str());
	server.sin_port =  htons(ServerPort);

	if( bind(sock_desc,(struct sockaddr *)&server , sizeof(server)) < 0)
    	{
        	cout<<"bind failed. Error"<<endl;				//print the error message
        	return 1;
    }
	else
    		cout<<"bind done"<<endl;
	
	listen(sock_desc,20);
	cout<<"Gateway waiting for connections"<<endl;

	ofstream displayfile;
	displayfile.open("GatewayDisplay.txt",ios::out|ios::trunc);
	displayfile.close();

	while(1)
	{
		cout<<"listening"<<endl;
		ClientLength=sizeof(client);
		ConnectionDescriptor=accept(sock_desc,(struct sockaddr *)&client,&ClientLength);
		if(ConnectionDescriptor<0)
		{
			cout<<"acceptfailed"<<endl;				//print the error message
			return 1;
		}
		else
			cout<<"connection accepted"<<endl;
	
		ThreadNo++;
		pthread_create(&Thread[ThreadNo - 1],NULL,IOT,(void*)&ConnectionDescriptor); 

//		sleep(2);
		 
	}

for(int i=0;i<ThreadNo;i++)     
pthread_join(Thread[i],NULL);
	
		
	return 0;
}

void *IOT(void *conndesc)							//function for receiving registering, current status, current value messages
{
	int client_sock=*(int*)conndesc;
	int ItemID=ThreadNo;
	while(1)
	{ 
	char client_message[1000];
	bzero(client_message, 1001);
	string Compare;
        int n=recv(client_sock , client_message , 100 , 0);
	if ( n < 0)
            {
	         cout<<"recv error \n"<<endl;
            }
	    if(n== 0)
	    {
	        close (client_sock);
	        break;
	    }
	cout<<"Message received from socket: "<<client_message<<endl<<"thread no "<<ItemID<<endl;

	string devicedata(client_message);

        		int delimiter1=devicedata.find("Type:")+5;
                        int delimiter2=devicedata.find(";Action:");
			Compare=devicedata.substr(delimiter1,delimiter2-delimiter1);

                        if(Compare.compare("Register")==0)
                        {
				int d3=devicedata.find(":",delimiter2+8,1);
                        	int d4=devicedata.find(":",d3+1,1);
                        	int d5=devicedata.find(":",d4+1,1);
                        
                                Device[ItemID].ItemId=ItemID;
                                Device[ItemID].TypeOfItem=devicedata.substr(delimiter2+8,d3-(delimiter2+8));
                                Device[ItemID].IpAddress=devicedata.substr(d3+1,d4-(d3+1));
                                Device[ItemID].PortNumber=devicedata.substr(d4+1,d5-(d4+1));
                                Device[ItemID].AreaId=devicedata.substr(d5+1,devicedata.size()-d5-1);
                                Device[ItemID].CurrentStatus = "off";
				
                                Device[ItemID].Conndes=client_sock;		//saving the connection descriptor value
					
				
			
                        }

			else if(Compare.compare("currValue")==0)
			{
				Device[ItemID].CurrentValue=devicedata.substr(delimiter2+8,2); 
				SmartDeviceMsg(ItemID);
				//DisplayCurrentState(ItemID);
			}

			else if(Compare.compare("currState")==0)
			{	
				Device[ItemID].CurrentStatus=devicedata.substr(delimiter2+8,3);
				DisplayCurrentState(ItemID);
			}
				devicedata.clear();
			if((Device[ItemID].TypeOfItem).compare("sensor")==0)
			pthread_create(&setval,NULL,setvalfunction,(void*)&client_sock);	
	}
}

void SmartDeviceMsg(int itemId)
{	
	string ItemType = "device";
	string CurrentAreaID = Device[itemId].AreaId;
	int pos=0;
	
	for(int Index = 0; Index <=50;Index++)
	{
		if(ItemType.compare(Device[Index].TypeOfItem) == 0 && Device[Index].AreaId == CurrentAreaID)
		{       
			pos=Index;						//index of device for that area
			break;
		}
				
	}
	
	string tempcurr=Device[itemId].CurrentValue;
	int temp=atoi(tempcurr.c_str());
	cout<<"Current Sensor temperature is "<<temp<<endl;
	if(pos!=0)
	{
	if(temp> 34)
	{	
		if(Device[pos].CurrentStatus.compare("off") != 0)		//checking with smart device;
		{
			DisplayCurrentState(itemId);
			string ServerMessage = "Type:Switch;Action:off";	// Send Type:Switch;Action:off to the Device located at the AreaID of the Sensor
			int q=write(Device[pos].Conndes ,ServerMessage.c_str() ,strlen(ServerMessage.c_str()));
			if(q<0)
			cout<<"unable to write"<<endl;				//print error message
			Device[pos].CurrentStatus="off";
		}
	}
	else if(temp < 32)
	{	
		if(Device[pos].CurrentStatus.compare("on") != 0)		//checking with smart device;
		{	
			DisplayCurrentState(itemId);
			string ServerMessage = "Type:Switch;Action:on";		//Send Type:Switch;Action:On to the Device located at the AreaID of the Sensor
			int w=write(Device[pos].Conndes, ServerMessage.c_str(), strlen(ServerMessage.c_str()));
			if(w<0)
			cout<<"unable to write"<<endl;				//print error message
			Device[pos].CurrentStatus="on";
		}
	}
		DisplayCurrentState(itemId);
	}
}

void DisplayCurrentState(int i)
{
	string ItemType = "device";
	string CurrentAreaID = Device[i].AreaId;
	int AreaValue=atoi(CurrentAreaID.c_str());
	int s;
	
	for(int Index = 0; Index <=50;Index++)
	{	
		if(ItemType.compare(Device[Index].TypeOfItem) == 0 && Device[Index].AreaId == CurrentAreaID)
		{
			s=Index;						//index of device for that area
			break;
		}
	}

	ofstream displayfile;
	displayfile.open("GatewayDisplay.txt",ios::app);			//create a file to print the output and appending all the outputs

	displayfile <<"-------------------------------------------------\n"<<Device[s].ItemId<<"-----"<<Device[s].IpAddress<<":"<<Device[s].PortNumber<<"-----"<<Device[s].TypeOfItem<<"-----"<<AreaValue<<"-----"<<Device[s].CurrentStatus<<endl<<Device[i].ItemId<<"-----"<<Device[i].IpAddress<<":"<<Device[i].PortNumber<<"-----"<<Device[i].TypeOfItem<<"-----"<<AreaValue<<"-----"<<Device[i].CurrentValue<<endl<<"-------------------------------------------------\n";
	displayfile.close();
}
