#include <cstring>
#include <unistd.h>
#include <stdio.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <stdlib.h>
#include <string>
#include <time.h>
#include <pthread.h>

using namespace std;

struct MyDetail
{
	string ItemType;					// Assigning Item type
	string AreaID;						// Sensor provided AreaID
	string CurrentState;					// Current Status (common for both sensor and device)
	string CurrentValue;					// Current Value (only Sensor provides this data)
	string MyIPAddress;					// IP Address of the sensor
	string MyPortNumber;					// Port number of the sensor
};

MyDetail myDetail;
int INTERVAL;
void *Temp(void*);
string TemperatureDetail;
int ServerSocketDescriptor=socket(AF_INET, SOCK_STREAM, 0);
int c;
char *ch;
int main(int argc, char *argv[])
{       
	ch=argv[2];
	string ConfigurationDetail;				// To hold data from the configuration file passed on to the Client program as command line argument
    	struct sockaddr_in ServerAddress, MyAddress;
	int MyListenDescriptor;
	pthread_t TaskThread;
	INTERVAL=7;
	//cout<<"enter the SensorConfigurationFile name"<<endl;


	ifstream configfile (argv[1]);	//open Sensor Configuration File and read the file
	if(configfile.is_open())
	{
            cout<<"reading sensorfile"<<endl;
		for(int Index=0;Index<2;Index++)
		{
			getline(configfile,ConfigurationDetail);

			if(Index==0)				//if its in first line of the file
			{
				int delimiter=ConfigurationDetail.find(":");
				string ServerIPAddress;
				int ServerPortNumber;
				ServerIPAddress=ConfigurationDetail.substr(0,delimiter);
				string temp=ConfigurationDetail.substr(delimiter+1,ConfigurationDetail.size()-(delimiter+1));
				ServerPortNumber=atoi(temp.c_str());

		         	memset(&ServerAddress,0,sizeof(ServerAddress));
		        	ServerAddress.sin_family=AF_INET;
		   	 	ServerAddress.sin_port=htons(ServerPortNumber);
				ServerAddress.sin_addr.s_addr=inet_addr(ServerIPAddress.c_str());
				

			int c=connect(ServerSocketDescriptor,(struct sockaddr*)&ServerAddress,sizeof(ServerAddress));
			if(c<0)
			cout<<"cannot connect"<<endl;		//prints error message
			}

	  		else					//if its in second line of the file
			{
			int delimiter=ConfigurationDetail.find(":");
			myDetail.ItemType=ConfigurationDetail.substr(0,delimiter);
			int delimiter2=ConfigurationDetail.find(":",delimiter+1,1);
			myDetail.MyIPAddress=ConfigurationDetail.substr(delimiter+1,delimiter2-(delimiter+1));
			int delimiter3=ConfigurationDetail.find(":",delimiter2+1,1);
			myDetail.MyPortNumber=ConfigurationDetail.substr(delimiter2+1,delimiter3-(delimiter2+1));
			myDetail.AreaID=ConfigurationDetail.substr(delimiter3+1,ConfigurationDetail.size()-(delimiter3+1));

			string RegisterMessage="Type:Register;Action:"+myDetail.ItemType+":"+myDetail.MyIPAddress+":"+myDetail.MyPortNumber+":"+myDetail.AreaID;
			char s[1000];
			bzero(s,1001);
			strcpy(s,RegisterMessage.c_str());
			int p=send(ServerSocketDescriptor,s,strlen(s),0);
			if(p<0)
			cout<<"sending failed"<<endl;		//prints error message
			}
		}
	}

	configfile.close();

	
                pthread_create(&TaskThread, NULL, Temp, (void*) &ServerSocketDescriptor);

		while(1)
		{
		char serverInstruction[1000];
		bzero(serverInstruction,1001);
		
		recv(ServerSocketDescriptor,serverInstruction,1001,0);
		cout<<serverInstruction<<endl;
		string ServerInstruction(serverInstruction);

		if(!(ServerInstruction.find("T")))
		{
			//cout<<"in set value function"<<endl;
			INTERVAL=atoi(serverInstruction);
		}

		}
	
	return 0;
}


void *Temp(void * serverSocketDescriptor)
{
	int d1,d2;
	//cout<<"enter the SensorInputFile name"<<endl;
	char *b;
	b=ch;
	int a=0;
	cout<<ch<<endl;

	while(1)
	{	
		ifstream TemperatureFile (b);
		if(TemperatureFile.is_open())
		{
		cout<<"reading temperature"<<endl;
		while(!TemperatureFile.eof())
		{
			string temperature;
			getline(TemperatureFile,temperature);		
			cout<<"in Temp function"<<endl;

			d1=temperature.find(";");
			d2=temperature.find(";",d1+1,1);
			string tempst=temperature.substr(0,d1);
			int StartTime=atoi(tempst.c_str());
			string tempend=temperature.substr(d1+1,d2-(d1+1));
			int EndTime=atoi(tempend.c_str());
			int difference=EndTime-StartTime;

		if(INTERVAL!=0)
		{
			difference= difference-a;
			a= difference-INTERVAL;
		while(a>INTERVAL)
		  {	
			
			if(a>=INTERVAL)
			{
				sleep(INTERVAL);
				a= a-INTERVAL;
			}
			else
			break;
			
			string ValueMessage = "Type:currValue;Action:" + temperature.substr(d2+1, (temperature.size() -(d2+1)));
			char u[100];
			bzero(u,1001);
			strcpy(u,ValueMessage.c_str());
			send(ServerSocketDescriptor, u, strlen(ValueMessage.c_str()),0);
		  }
		}
		sleep(difference);
		cout<<"sending currValue"<<endl;		
		string ValueMessage = "Type:currValue;Action:" + temperature.substr(d2+1, (temperature.size() -(d2+1)));
		cout<<ValueMessage<<endl;
		        char k[1000];
			bzero(k,1001);
                        strcpy(k,ValueMessage.c_str());
                        int l=send(ServerSocketDescriptor,k,strlen(k),0);
		if(l<0)
		cout<<"sending failed"<<endl;
	        }
		}
TemperatureFile.close();
}
}
